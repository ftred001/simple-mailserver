#ifndef SMTP_H
#define SMTP_H

int process_smtp(int infd, int outfd);

#endif
