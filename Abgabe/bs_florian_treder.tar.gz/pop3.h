#ifndef POP3_H
#define POP3_H
int process_pop3(int infd, int outfd);

#endif
