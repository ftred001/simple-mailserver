#include <stdio.h>
#include <stdlib.h>
#include <limits.h> /* strtoul */
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

#include "database.h"
#include "dialog.h"
#include "dbm.h"


int speichern(int fd, DBRecord *dbr);
int match_filter(DBRecord *rec, const void *data);


int key_filter(DBRecord *rec, const void *data) {
    if (strstr(rec->key, data)) {
		return 1;
	}
    return 0;
}

int cat_filter(DBRecord *rec, const void *data) {
    if (strstr(rec->cat, data)) {
		return 1;
	}
    return 0;
}

int match_filter(DBRecord *rec, const void *data) {
	if (strlen(data) == 0) {
		return 2;
	}
	
	if (strstr(rec->key, data)) {
		return 1;
	}
	if (strstr(rec->cat, data)) {
		return 1;
	}
	return 0;
}

int execute_cmd(const char *filepath, int argc, char *line) {
	int fd;
	int outfd = 1;
	int i=0;
	long index;
	DBRecord rec;
	char *errstring;
	const char delimiter[] = " ";
	char *argv[10]; /* Maximale Anzahl an Parametern. */
	char *mem = (char*)calloc(LINEMAX, sizeof(char));
	char *wort = (char*)calloc(LINEMAX, sizeof(char));
	
	memset(&rec, 0, sizeof(DBRecord));
	
	sprintf(mem, "%s", line);
	
	wort = strtok(mem, delimiter);
	
	for (i=0; i<=argc; i++) {
		if (wort != NULL) {
			argv[i] = (char*)calloc(LINEMAX, sizeof(char));
			strcpy(argv[i], wort);
			wort = strtok(NULL, delimiter);	
		}
	}
	
	
	/* Erstellt Datei, falls nicht existiert */
	if (strlen(filepath)) {
		fd = open(filepath, O_RDONLY|O_CREAT,0644);
	} else {
		fd = open(STD_FILEPATH, O_RDONLY|O_CREAT,0644);
	}
	
	close(fd);

	
	if (argc == 1) {
		if (!strcmp(argv[0], "list")) {	
			printf("===LIST ALL===\n");
			db_list(filepath, outfd, match_filter,""); 
		}
	}
	
	if (argc == 2) {
        /* List mit Key Filter */
		if (!strcmp(argv[0], "list")) {
			printf("===LIST===\n");
            db_list(filepath, outfd, key_filter,argv[1]); 
        }
        
        /* List mit Catfilter */
		if (!strcmp(argv[0], "clist")) {
			printf("===CLIST===\n");
            db_list(filepath, outfd, cat_filter,argv[1]); 
        }
        
        /* Suche: Key oder Cat */
        /* "search keyword" */
		if (!strcmp(argv[0], "search")) {
			printf("===SEARCH KEY || CAT ===\n");
			strcpy(rec.key,argv[1]);
			strcpy(rec.cat,argv[1]);
			printf("Search Result:%d\n", db_search(filepath, 0, &rec));
		}
        
		/* Lösche Indexnummer */
		/* "delete indexnummer" */
        if (!strcmp(argv[0], "delete")) {
			index = strtoul(argv[1], &errstring, 10);
            db_del(filepath, index);
		}
	}
	
	if (argc == 3) {
		/* Suche: Key UND Cat */
        /* "search keyword" */
		if (!strcmp(argv[0], "search")) {
			printf("===SEARCH Key && CAT===\n");
			strcpy(rec.key,argv[1]);
			strcpy(rec.cat,argv[2]);
			printf("Search Result:%d\n", db_search(filepath, 0, &rec));
		}
	
	}
		
	if (argc == 4) {
		
		if (!strcmp(argv[0], "update")) {
			strcpy(rec.key,argv[1]);
			strcpy(rec.value,argv[2]);
			strcpy(rec.value, argv[3]);
			db_update(filepath, &rec);
		}
		
		if (!strcmp(argv[0], "add")) {
			strcpy(rec.key,argv[1]);
			strcpy(rec.cat,argv[2]);
			strcpy(rec.value,argv[3]);
			
			if (db_search(filepath, 0, &rec) == -1) {
				db_put(filepath, -1, &rec);
			} else {
				printf("Already exists. Did you mean update?\n");
			}
		}
	}
	
	free(wort);
	free(mem);
	
	return 0;
}

void create_testdata(char line[LINEMAX]) {
	char *mem = (char*)calloc(LINEMAX, sizeof(char));
	int linecounter;
	char *wort = (char*)calloc(LINEMAX, sizeof(char));
	char delimiter[] = " "; 
		
	
	sprintf(mem, "%s",line);
	
	linecounter = 0;
	
	wort = strtok(mem, delimiter);

	while(wort != NULL) {
		linecounter++;
		wort = strtok(NULL, delimiter);
	}
	execute_cmd(STD_FILEPATH, linecounter, line);
	free(mem);
	free(wort);
}

int main(int argc, char *argv[]) {
	create_testdata("add joendhard mailbox joendhard.mbox");
	create_testdata("add joendhard password biffel");
	create_testdata("add port pop3 127.0.0.1");
	create_testdata("add host pop3 8110");
	create_testdata("add port smtp 8025");
	create_testdata("add host smtp 127.0.0.1");
	create_testdata("add j.biffel@mymaildings.de smtp joendhard");
	
	create_testdata("list");
	
	printf("=======\nDataBaseManager FINISHED======\n");
	
	
	return 0;
}
